global using System.Diagnostics;
