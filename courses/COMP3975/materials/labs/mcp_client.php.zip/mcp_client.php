#!/usr/bin/env php
<?php

/**
 * MCP Client for the Todo MCP Server
 *
 * A PHP client that consumes the MCP server via Streamable HTTP transport
 * at http://localhost:8000/mcp/todo
 *
 * Usage:
 *   php mcp_client.php                  - Run interactive mode
 *   php mcp_client.php initialize       - Initialize a session
 *   php mcp_client.php list-tools       - List available tools
 *   php mcp_client.php call-tool <name> - Call a tool with JSON arguments
 */
class McpClient
{
    private string $baseUrl;

    private ?string $sessionId = null;

    private int $requestId = 0;

    public function __construct(string $baseUrl)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    /**
     * Send a JSON-RPC 2.0 request to the MCP server and parse the SSE response.
     */
    private function sendRequest(string $method, array $params = [], bool $isNotification = false): ?array
    {
        $this->requestId++;

        $payload = [
            'jsonrpc' => '2.0',
            'method' => $method,
        ];

        if (! empty($params)) {
            $payload['params'] = $params;
        }

        if (! $isNotification) {
            $payload['id'] = $this->requestId;
        }

        $jsonBody = json_encode($payload);

        $headers = [
            'Content-Type: application/json',
            'Accept: text/event-stream',
        ];

        if ($this->sessionId !== null) {
            $headers[] = 'Mcp-Session-Id: '.$this->sessionId;
        }

        $ch = curl_init($this->baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $jsonBody,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_TIMEOUT => 30,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            throw new RuntimeException("cURL error: {$error}");
        }

        $responseHeaders = substr($response, 0, $headerSize);
        $responseBody = substr($response, $headerSize);

        // Extract session ID from response headers
        if (preg_match('/Mcp-Session-Id:\s*(.+)/i', $responseHeaders, $matches)) {
            $this->sessionId = trim($matches[1]);
        }

        if ($httpCode < 200 || $httpCode >= 300) {
            throw new RuntimeException("HTTP {$httpCode}: {$responseBody}");
        }

        // For notifications, no response body is expected
        if ($isNotification) {
            return null;
        }

        // Parse SSE response (text/event-stream)
        return $this->parseSseResponse($responseBody);
    }

    /**
     * Parse a Server-Sent Events response body and extract the JSON-RPC result.
     */
    private function parseSseResponse(string $body): ?array
    {
        // Try parsing as plain JSON first (some implementations return JSON directly)
        $decoded = json_decode(trim($body), true);
        if ($decoded !== null) {
            return $decoded;
        }

        // Parse SSE format: look for "data:" lines
        $result = null;
        $lines = explode("\n", $body);
        foreach ($lines as $line) {
            $line = trim($line);
            if (str_starts_with($line, 'data:')) {
                $data = trim(substr($line, 5));
                $decoded = json_decode($data, true);
                if ($decoded !== null) {
                    $result = $decoded;
                }
            }
        }

        return $result;
    }

    /**
     * Initialize the MCP session with the server.
     */
    public function initialize(): array
    {
        $result = $this->sendRequest('initialize', [
            'protocolVersion' => '2025-03-26',
            'capabilities' => new \stdClass,
            'clientInfo' => [
                'name' => 'php-mcp-client',
                'version' => '1.0.0',
            ],
        ]);

        // Send initialized notification
        $this->sendRequest('notifications/initialized', [], true);

        return $result;
    }

    /**
     * List all available tools on the server.
     */
    public function listTools(): array
    {
        return $this->sendRequest('tools/list') ?? [];
    }

    /**
     * Call a tool by name with the given arguments.
     */
    public function callTool(string $toolName, array $arguments = []): array
    {
        return $this->sendRequest('tools/call', [
            'name' => $toolName,
            'arguments' => $arguments,
        ]) ?? [];
    }

    /**
     * Ping the server.
     */
    public function ping(): array
    {
        return $this->sendRequest('ping') ?? [];
    }

    public function getSessionId(): ?string
    {
        return $this->sessionId;
    }
}

// ---------------------------------------------------------------------------
// CLI Interface
// ---------------------------------------------------------------------------

function printBanner(): void
{
    echo "\n";
    echo "========================================\n";
    echo "  MCP Todo Client (Streamable HTTP)     \n";
    echo "  Server: http://localhost:8000/mcp/todo \n";
    echo "========================================\n";
    echo "\n";
}

function printHelp(): void
{
    echo "Commands:\n";
    echo "  initialize   - Initialize a session with the MCP server\n";
    echo "  list-tools   - List available tools\n";
    echo "  call-tool    - Call a tool interactively\n";
    echo "  add-todo     - Shortcut: add a to-do item\n";
    echo "  ping         - Ping the server\n";
    echo "  help         - Show this help message\n";
    echo "  quit         - Exit the client\n";
    echo "\n";
}

function printJson(mixed $data): void
{
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)."\n";
}

function prompt(string $message): string
{
    echo $message;

    return trim(fgets(STDIN));
}

function runInteractive(): void
{
    printBanner();

    $client = new McpClient('http://localhost:8000/mcp/todo');

    // Auto-initialize on start
    echo "[*] Initializing session...\n";
    try {
        $result = $client->initialize();
        echo '[+] Session initialized. Session ID: '.($client->getSessionId() ?? 'N/A')."\n";
        echo "[+] Server info:\n";
        printJson($result['result'] ?? $result);
    } catch (RuntimeException $e) {
        echo '[-] Failed to initialize: '.$e->getMessage()."\n";
        echo "    Make sure the server is running at http://localhost:8000/mcp/todo\n";

        return;
    }

    echo "\n";
    printHelp();

    while (true) {
        $input = prompt('mcp> ');

        if ($input === '' || $input === false) {
            continue;
        }

        switch ($input) {
            case 'initialize':
                try {
                    $result = $client->initialize();
                    echo "[+] Session re-initialized.\n";
                    printJson($result['result'] ?? $result);
                } catch (RuntimeException $e) {
                    echo '[-] Error: '.$e->getMessage()."\n";
                }
                break;

            case 'list-tools':
                try {
                    $result = $client->listTools();
                    echo "[+] Available tools:\n";
                    $tools = $result['result']['tools'] ?? $result['tools'] ?? [];
                    if (empty($tools)) {
                        echo "    (no tools found)\n";
                    }
                    foreach ($tools as $tool) {
                        echo '    - '.($tool['name'] ?? 'unknown')."\n";
                        if (isset($tool['description'])) {
                            echo '      '.$tool['description']."\n";
                        }
                        if (isset($tool['inputSchema']['properties'])) {
                            echo "      Parameters:\n";
                            foreach ($tool['inputSchema']['properties'] as $prop => $schema) {
                                $type = $schema['type'] ?? 'any';
                                $desc = $schema['description'] ?? '';
                                echo "        {$prop} ({$type}): {$desc}\n";
                            }
                        }
                    }
                } catch (RuntimeException $e) {
                    echo '[-] Error: '.$e->getMessage()."\n";
                }
                break;

            case 'call-tool':
                $toolName = prompt('  Tool name: ');
                $argsJson = prompt('  Arguments (JSON): ');
                $arguments = json_decode($argsJson, true);
                if ($argsJson !== '' && $arguments === null) {
                    echo "[-] Invalid JSON for arguments.\n";
                    break;
                }
                try {
                    $result = $client->callTool($toolName, $arguments ?? []);
                    echo "[+] Tool result:\n";
                    printJson($result['result'] ?? $result);
                } catch (RuntimeException $e) {
                    echo '[-] Error: '.$e->getMessage()."\n";
                }
                break;

            case 'add-todo':
                $description = prompt('  Description: ');
                $isDoneInput = prompt('  Is done? (yes/no) [no]: ');
                $isDone = in_array(strtolower($isDoneInput), ['yes', 'y', 'true', '1'], true);
                $date = prompt('  Date (YYYY-MM-DD) [today]: ');
                if ($date === '') {
                    $date = date('Y-m-d');
                }

                try {
                    $result = $client->callTool('add-todo-tool', [
                        'description' => $description,
                        'isDone' => $isDone,
                        'created_at' => $date,
                    ]);
                    echo "[+] Todo added!\n";
                    printJson($result['result'] ?? $result);
                } catch (RuntimeException $e) {
                    echo '[-] Error: '.$e->getMessage()."\n";
                }
                break;

            case 'ping':
                try {
                    $result = $client->ping();
                    echo "[+] Pong!\n";
                    printJson($result);
                } catch (RuntimeException $e) {
                    echo '[-] Error: '.$e->getMessage()."\n";
                }
                break;

            case 'help':
                printHelp();
                break;

            case 'quit':
            case 'exit':
                echo "Goodbye!\n";

                return;

            default:
                echo "Unknown command: {$input}. Type 'help' for available commands.\n";
                break;
        }

        echo "\n";
    }
}

// ---------------------------------------------------------------------------
// Non-interactive CLI mode
// ---------------------------------------------------------------------------

function runCommand(array $argv): void
{
    $client = new McpClient('http://localhost:8000/mcp/todo');
    $command = $argv[1] ?? 'help';

    switch ($command) {
        case 'initialize':
            $result = $client->initialize();
            printJson($result['result'] ?? $result);
            break;

        case 'list-tools':
            $client->initialize();
            $result = $client->listTools();
            printJson($result['result'] ?? $result);
            break;

        case 'call-tool':
            $toolName = $argv[2] ?? null;
            $argsJson = $argv[3] ?? '{}';
            if (! $toolName) {
                echo "Usage: php mcp_client.php call-tool <tool-name> [json-arguments]\n";
                echo "Example: php mcp_client.php call-tool add-todo-tool '{\"description\":\"Buy milk\",\"isDone\":false,\"created_at\":\"2026-03-13\"}'\n";
                exit(1);
            }
            $arguments = json_decode($argsJson, true);
            if ($arguments === null && $argsJson !== '{}') {
                echo "Invalid JSON arguments.\n";
                exit(1);
            }
            $client->initialize();
            $result = $client->callTool($toolName, $arguments ?? []);
            printJson($result['result'] ?? $result);
            break;

        case 'ping':
            $client->initialize();
            $result = $client->ping();
            printJson($result);
            break;

        default:
            echo "MCP Todo Client - PHP CLI\n\n";
            echo "Usage:\n";
            echo "  php mcp_client.php                                    - Interactive mode\n";
            echo "  php mcp_client.php initialize                         - Initialize session\n";
            echo "  php mcp_client.php list-tools                         - List available tools\n";
            echo "  php mcp_client.php call-tool <name> [json-args]       - Call a specific tool\n";
            echo "  php mcp_client.php ping                               - Ping the server\n";
            echo "\nExamples:\n";
            echo "  php mcp_client.php list-tools\n";
            echo "  php mcp_client.php call-tool add-todo-tool '{\"description\":\"Buy milk\",\"isDone\":false,\"created_at\":\"2026-03-13\"}'\n";
            break;
    }
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

if (php_sapi_name() !== 'cli') {
    echo "This script must be run from the command line.\n";
    exit(1);
}

if ($argc <= 1) {
    // No arguments → interactive mode
    runInteractive();
} else {
    runCommand($argv);
}
