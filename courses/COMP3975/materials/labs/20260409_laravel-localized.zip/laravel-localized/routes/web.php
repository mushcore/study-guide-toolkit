<?php

use Illuminate\Support\Facades\Route;

// localization route
Route:: get ('language/{locale}', function ($locale) {
    app()->setLocale($locale);
    session()->put('locale', $locale);
    return redirect()->back();
});

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/{locale?}', function ($locale = null) {
//     if (isset($locale) && in_array($locale, config('app.supported_locales'))) {
//         app()->setLocale($locale);
//     }
//     return view('welcome');
// });

