<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <p class="quote"><?php echo e(__('Beautiful British Columbia')); ?></p>
    </div>
</div>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title"><?php echo e(__('Natural Beauty')); ?></h1>
        <p><?php echo e(__('The North of British Columbia is a less visited area of Canada, but it offers so much in the way of pure, unadulterated natural beauty.')); ?></p>
        <p><a href="#"><?php echo e(__('Read more...')); ?></a></p>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title"><?php echo e(__('Vancouver Island & Victoria')); ?></h1>
        <p><?php echo e(__('Vancouver Island offers one of the world’s most divergent ecosystems on the planet.')); ?></p>
        <p><a href="#"><?php echo e(__('Read more...')); ?></a></p>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title"><?php echo e(__('Whale and Orca spotting')); ?></h1>
        <p><?php echo e(__('British Columbia is one of only a few destinations where you can experience a three hour whale watching boat trip!')); ?></p>
        <p><a href="#"><?php echo e(__('Read more...')); ?></a></p>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/medhatelmasry/Downloads/laravel-intro/resources/views/welcome.blade.php ENDPATH**/ ?>