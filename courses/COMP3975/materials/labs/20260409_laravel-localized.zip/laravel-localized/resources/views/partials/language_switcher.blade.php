<div class="flex justify-center pt-8 sm:justify-start sm:pt-0">
    @foreach ($available_locales as $locale)
        @if($locale === $current_locale)
            <span class="ml-2 mr-2 text-gray-700">{{ strtoupper($locale) }}</span>
        @else
            <a class="ml-1 underline ml-2 mr-2" href="language/{{ $locale }}">
                <span>{{ strtoupper($locale) }}</span>
            </a>&nbsp;|&nbsp;
        @endif
    @endforeach
</div>
