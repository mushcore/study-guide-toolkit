@extends('layouts.master')

@section('content')
<div class="row">
    <div class="col-md-12">
        <p class="quote">{{ __('Beautiful British Columbia') }}</p>
    </div>
</div>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title">{{ __('Natural Beauty') }}</h1>
        <p>{{ __('The North of British Columbia is a less visited area of Canada, but it offers so much in the way of pure, unadulterated natural beauty.') }}</p>
        <p><a href="#">{{ __('Read more...') }}</a></p>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title">{{ __('Vancouver Island & Victoria') }}</h1>
        <p>{{ __('Vancouver Island offers one of the world’s most divergent ecosystems on the planet.') }}</p>
        <p><a href="#">{{ __('Read more...') }}</a></p>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title">{{ __('Whale and Orca spotting') }}</h1>
        <p>{{ __('British Columbia is one of only a few destinations where you can experience a three hour whale watching boat trip!') }}</p>
        <p><a href="#">{{ __('Read more...') }}</a></p>
    </div>
</div>

@endsection
