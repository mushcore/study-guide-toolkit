<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel Rocks</title>
        <link href='http://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
        {{-- <link rel="stylesheet" href="css/styles.css"> --}}
        <link rel="stylesheet" href="{{ asset('css/styles.css') }}"><link>
    </head>
    <body>
        @include('partials.header')
        <div class="container">
        @yield('content')
        </div>
    </body>
</html>
