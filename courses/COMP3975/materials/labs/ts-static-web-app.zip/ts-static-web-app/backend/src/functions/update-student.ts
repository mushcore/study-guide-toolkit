import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { Student } from "../shared/student-model";
import { StudentPayload } from "../shared/student-payload";
import { initializeDatabase } from "../shared/database";

export async function UpdateStudent(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    try {
        context.log(`Full request URL: ${request.url}`);
        context.log(`Request method: ${request.method}`);

        // Initialize the database and models
        await initializeDatabase();

        // Extract StudentId from the URL path
        // URL format: /api/students/{StudentId} or students/{StudentId}
        let studentId = request.url.split('/').pop() || '';
        // Remove query parameters if any
        studentId = studentId.split('?')[0].trim();

        context.log(`Extracted StudentId: '${studentId}'`);

        if (!studentId) {
            context.log('StudentId is empty or missing');
            return { status: 400, body: "Student ID is required." };
        }

        // Explicitly type the body as Partial<StudentPayload>
        const body = await request.json() as Partial<StudentPayload>;

        // Validate and typecast the payload
        const updates: Partial<StudentPayload> = {
            FirstName: body.FirstName,
            LastName: body.LastName,
            School: body.School,
        };

        if (!updates.FirstName && !updates.LastName && !updates.School) {
            return { status: 400, body: JSON.stringify({ error: "At least one field (FirstName, LastName, School) is required to update." }), headers: { "Content-Type": "application/json" } };
        }

        // Fetch the student by ID
        const student = await Student.findByPk(studentId);

        if (!student) {
            return { status: 404, body: JSON.stringify({ error: "Student not found." }), headers: { "Content-Type": "application/json" } };
        }

        // Update the student record
        await student.update(updates);

        return { body: JSON.stringify(student), headers: { "Content-Type": "application/json" } };
    } catch (err) {
        context.log(`Error: ${err}`);
        context.log(`Error stack: ${err instanceof Error ? err.stack : 'No stack trace'}`);
        const errorMessage = err instanceof Error ? err.message : String(err);
        return { status: 500, body: JSON.stringify({ error: errorMessage }), headers: { "Content-Type": "application/json" } };
    }
}

app.http('UpdateStudent', {
    methods: ['PUT', 'PATCH'],
    authLevel: 'anonymous',
    route: 'students/{StudentId}',
    handler: UpdateStudent
});
