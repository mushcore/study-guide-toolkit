import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { connectToDatabase, closeDatabaseConnection } from "../shared/database";
import { initializeDatabase } from "../shared/database";

export async function DeleteStudentById(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    try {
        context.log(`Full request URL: ${request.url}`);
        context.log(`Request method: ${request.method}`);

        // Initialize the database and models
        await initializeDatabase();

        // Extract StudentId from the URL path
        // URL format: /api/students/{StudentId} or students/{StudentId}
        let studentId = request.url.split('/').pop() || '';
        // Remove query parameters if any
        studentId = studentId.split('?')[0].trim();

        context.log(`Extracted StudentId: '${studentId}'`);

        if (!studentId) {
            context.log('StudentId is empty or missing');
            return { status: 400, body: JSON.stringify({ error: "Student ID is required." }), headers: { "Content-Type": "application/json" } };
        }

        let pool;

        try {
            pool = await connectToDatabase();
            const result = await pool.request()
                .input("StudentId", studentId)
                .query("DELETE FROM Students WHERE StudentId = @StudentId");

            if (result.rowsAffected[0] === 0) {
                return { status: 404, body: JSON.stringify({ error: "Student not found." }), headers: { "Content-Type": "application/json" } };
            }

            return { status: 200, body: JSON.stringify({ message: "Student deleted successfully." }), headers: { "Content-Type": "application/json" } };
        } catch (err) {
            context.log(`Error: ${err}`);
            context.log(`Error stack: ${err instanceof Error ? err.stack : 'No stack trace'}`);
            const errorMessage = err instanceof Error ? err.message : String(err);
            return { status: 500, body: JSON.stringify({ error: errorMessage }), headers: { "Content-Type": "application/json" } };
        } finally {
            if (pool) {
                await closeDatabaseConnection(pool);
            }
        }
    } catch (err) {
        context.log(`Outer error: ${err}`);
        const errorMessage = err instanceof Error ? err.message : String(err);
        return { status: 500, body: JSON.stringify({ error: errorMessage }), headers: { "Content-Type": "application/json" } };
    }
}

app.http('DeleteStudentById', {
    methods: ['DELETE'],
    authLevel: 'anonymous',
    route: 'students/{StudentId}',
    handler: DeleteStudentById
});
