import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { Student } from "../shared/student-model";
import { initializeDatabase } from "../shared/database";

export async function GetStudentById(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> {
    try {
        context.log(`Full request URL: ${request.url}`);
        context.log(`Request method: ${request.method}`);

        // Initialize the database and models
        await initializeDatabase();

        // Extract StudentId from the URL path
        // URL format: /api/students/{StudentId} or students/{StudentId}
        let studentId = request.url.split('/').pop() || '';
        // Remove query parameters if any
        studentId = studentId.split('?')[0].trim();

        context.log(`Extracted StudentId: '${studentId}'`);

        if (!studentId) {
            context.log('StudentId is empty or missing');
            return { status: 400, body: JSON.stringify({ error: "Student ID is required." }), headers: { "Content-Type": "application/json" } };
        }

        context.log(`Looking for student with ID: ${studentId}`);

        // Find the student by primary key
        const student = await Student.findByPk(studentId);

        if (!student) {
            context.log(`Student with ID ${studentId} not found`);
            return { status: 404, body: JSON.stringify({ error: "Student not found." }), headers: { "Content-Type": "application/json" } };
        }

        context.log(`Found student: ${student.toJSON()}`);

        // Return the student as JSON
        return {
            body: JSON.stringify(student.toJSON()),
            headers: { "Content-Type": "application/json" }
        };
    } catch (err) {
        context.log(`Error: ${err}`);
        context.log(`Error stack: ${err instanceof Error ? err.stack : 'No stack trace'}`);
        const errorMessage = err instanceof Error ? err.message : String(err);
        return { status: 500, body: JSON.stringify({ error: errorMessage }), headers: { "Content-Type": "application/json" } };
    }
}

app.http('GetStudentById', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'students/{StudentId}',
    handler: GetStudentById
});
