import * as sql from "mssql";
import { Sequelize, DataTypes } from "sequelize";
import { Student, StudentModel } from "./student-model";

// Parse the connection string from environment variables - try multiple possible names
const getConnectionString = (): string | undefined => {
    // Try different environment variable names
    const possible = [
        process.env.DATABASE_CONNECTION_STRING,
        process.env.SQL_SERVER_CONNECTION_STRING,
        process.env.DATABASE_URL,
        process.env.SQLCONNSTR_DefaultConnection, // Azure App Service convention
    ];

    const connectionString = possible.find(str => str && str.trim());
    if (connectionString) {
        console.log(`Using connection string from env var (first 50 chars): ${connectionString.substring(0, 50)}...`);
    } else {
        console.error('No connection string found in environment variables. Checked: DATABASE_CONNECTION_STRING, SQL_SERVER_CONNECTION_STRING, DATABASE_URL, SQLCONNSTR_DefaultConnection');
    }
    return connectionString;
};

const connectionString: string | undefined = getConnectionString();

// Sequelize instance
let sequelizeInstance: Sequelize | null = null;

export async function connectToDatabase(): Promise<sql.ConnectionPool> {
    try {
        console.log('Attempting database connection...');

        if (!connectionString) {
            console.error('SQL_SERVER_CONNECTION_STRING environment variable is not set');
            throw new Error('Database connection string is not configured');
        }

        const pool: sql.ConnectionPool = await sql.connect(connectionString);
        console.log('Database connection established successfully');
        return pool;
    } catch (err: any) {
        console.error('Database connection failed:', err.message);
        console.error('Stack trace:', err.stack);
        throw err;
    }
}

export async function closeDatabaseConnection(pool: sql.ConnectionPool): Promise<void> {
    try {
        if (pool) {
            await pool.close();
            console.log('Database connection closed successfully');
        }
    } catch (err: any) {
        console.error('Error closing database connection:', err.message);
        console.error('Stack trace:', err.stack);
    }
}

export function getSequelize(): Sequelize {
    if (!sequelizeInstance) {
        if (!connectionString) {
            throw new Error("DATABASE_CONNECTION_STRING environment variable is not set");
        }

        console.log("Raw connection string:", connectionString.substring(0, 50) + "...");

        // Parse the connection string - more robust parsing
        const config: any = {};
        const connectionParts = connectionString.split(';').filter(part => part.trim());

        connectionParts.forEach(part => {
            const [key, value] = part.split('=');
            if (key && value) {
                const trimmedKey = key.trim().toLowerCase();
                const trimmedValue = value.trim();

                // Map common connection string keys
                if (trimmedKey === 'server' || trimmedKey === 'host') {
                    config.server = trimmedValue;
                } else if (trimmedKey === 'database' || trimmedKey === 'initial catalog') {
                    config.database = trimmedValue;
                } else if (trimmedKey === 'uid' || trimmedKey === 'user id' || trimmedKey === 'user') {
                    config.username = trimmedValue;
                } else if (trimmedKey === 'pwd' || trimmedKey === 'password') {
                    config.password = trimmedValue;
                }
            }
        });

        console.log("Parsed config keys:", Object.keys(config).join(', '));

        if (!config.server || !config.database || !config.username || !config.password) {
            console.error("Missing connection parts:", {
                server: config.server ? "✓" : "✗",
                database: config.database ? "✓" : "✗",
                username: config.username ? "✓" : "✗",
                password: config.password ? "✓" : "✗"
            });
            throw new Error("Connection string is missing required parts: " +
                `server=${!config.server}, database=${!config.database}, username=${!config.username}, password=${!config.password}`);
        }

        // Extract server and port
        let host = config.server;
        let port = 1433; // Default SQL Server port

        // Handle "Server=tcp:127.0.0.1,1444" or "Server=myserver.database.windows.net" formats
        if (host.includes(',')) {
            // Format: server,port (e.g., "tcp:127.0.0.1,1444")
            const serverParts = host.replace('tcp:', '').split(',');
            host = serverParts[0];
            port = parseInt(serverParts[1], 10) || 1433;
        } else if (host.includes(':')) {
            // Format: protocol:server (e.g., "tcp:myserver.database.windows.net")
            const parts = host.split(':');
            host = parts[1] || parts[0];
        }

        // Replace IP with 'localhost' if needed
        if (host === '127.0.0.1') {
            host = 'localhost';
        }

        console.log(`Connecting to ${host}:${port} with database ${config.database}`);

        // Create a new Sequelize instance
        sequelizeInstance = new Sequelize({
            dialect: "mssql",
            host: host,
            port: port,
            database: config.database,
            username: config.username,
            password: config.password,
            logging: false,
            dialectOptions: {
                options: {
                    trustServerCertificate: true,
                    encrypt: true  // Required for Azure SQL
                }
            }
        });

        // Initialize the Student model
        Student.init(StudentModel, {
            sequelize: sequelizeInstance,
            modelName: "Student",
            tableName: "Students",
            timestamps: false
        });
    }

    return sequelizeInstance;
}

// Ensure database connection and model synchronization
export async function initializeDatabase(): Promise<void> {
    try {
        const sequelize = getSequelize();
        await sequelize.authenticate();
        console.log("Sequelize database connection established successfully");
        await sequelize.sync();
        console.log("Database models synchronized");
    } catch (err) {
        console.error("Unable to connect to the database or synchronize models:", err);
        throw err;
    }
}
