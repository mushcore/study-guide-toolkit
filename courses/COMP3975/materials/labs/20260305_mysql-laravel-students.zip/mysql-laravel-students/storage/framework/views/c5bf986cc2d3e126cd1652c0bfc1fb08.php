<?php $__env->startSection('title', 'Show Student'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Show Student</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('students.index')); ?>">Back</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <?php echo e($student->FirstName); ?> <?php echo e($student->LastName); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>School:</strong>
                <?php echo e($student->School); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/medhatelmasry/_PlayGround/3975/week09/mysql-laravel-students/resources/views/students/show.blade.php ENDPATH**/ ?>