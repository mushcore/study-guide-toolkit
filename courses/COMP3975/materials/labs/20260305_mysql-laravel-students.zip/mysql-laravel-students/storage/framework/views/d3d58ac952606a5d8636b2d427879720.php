<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>
<span style="font-size:xx-large;">Laravel with MySQL</span>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/medhatelmasry/_PlayGround/3975/week09/mysql-laravel-students/resources/views/welcome.blade.php ENDPATH**/ ?>