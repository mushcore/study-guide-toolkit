@extends('layouts.master')

@section('title', 'Home Page')

@section('content')
<span style="font-size:xx-large;">Laravel with MySQL</span>
@endsection
