<?php

use App\Http\Controllers\api\AuthController;
use App\Http\Controllers\api\StudentsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Route::get('students', [StudentsController::class, 'index']);
// Route::get('students/{student}', [StudentsController::class, 'show']);
// Route::post('students', [StudentsController::class, 'store']);
// Route::put('students/{student}', [StudentsController::class, 'update']);
// Route::delete('students/{student}', [StudentsController::class, 'destroy']);

Route::middleware('auth:sanctum')->group(function () {
    Route::resource('students', StudentsController::class);
});

Route::controller(AuthController::class)->group(function () {
    Route::post('login', 'login');
    Route::post('register', 'register');
    Route::post('logout', 'logout');
    Route::post('refresh', 'refresh');
});
