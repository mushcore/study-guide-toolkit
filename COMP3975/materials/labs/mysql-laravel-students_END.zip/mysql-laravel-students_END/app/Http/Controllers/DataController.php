<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Support\Facades\DB;

class DataController extends Controller
{
    public function raw()
    {
        $students = DB::select('SELECT FirstName, LastName, School FROM students WHERE LastName LIKE "M%" ORDER BY FirstName');
        dd($students);
    }

    public function qbuilder()
    {
        $students = DB::table('students')
            ->select(['FirstName', 'LastName', 'School'])
            ->whereNotNull('School')
            ->orderBy('FirstName')
            ->get();

        dd($students);
    }

    public function elo()
    {
        // $students = Student::all();
        DB::enableQueryLog();

        $students = Student::select(['FirstName', 'LastName', 'School'])
            ->whereNotNull('School')
            ->where('FirstName', 'LIKE', 'A%')
            ->orderBy('FirstName')
            ->get();

        // dd(DB::getQueryLog());

        // dd($students);
        foreach ($students as $item) {
            echo $item->FirstName . ' ' . $item->LastName . '<br />';
        }

        echo "<pre>";
        print_r(DB::getQueryLog());
        echo "</pre>";
    }
}
