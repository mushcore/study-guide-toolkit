<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" >
        <title>Students love Laravel - <?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>
<?php /**PATH /Users/medhatelmasry/_PlayGround/3975/week11/mysql-laravel-students/resources/views/layouts/master.blade.php ENDPATH**/ ?>