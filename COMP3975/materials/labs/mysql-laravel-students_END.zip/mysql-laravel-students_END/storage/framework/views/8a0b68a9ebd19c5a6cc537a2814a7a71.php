<?php $__env->startSection('title', 'Students List'); ?>

<?php $__env->startSection('content'); ?> 

<div class="row">
    <div class="col-lg-12">
        <div class="pull-left">
            <h2>Students List</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success btn-sm" href="<?php echo e(route('students.create')); ?>"> 
                Create New Student
            </a>
        </div>
    </div>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>


<table class="table table-striped">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>School</th>
    <th></th>
</tr>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->FirstName); ?> <?php echo e($item->LastName); ?></td>
        <td><?php echo e($item->School); ?></td>
        <td>           
            <a class="btn btn-info btn-sm" href="<?php echo e(route('students.show',$item->id)); ?>">Show</a>
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('students.edit',$item->id)); ?>">Edit</a>
            <a class="btn btn-danger btn-sm" href="<?php echo e(route('students.destroy',$item->id)); ?>">Del</a>
        </td>        
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($students->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/medhatelmasry/_PlayGround/3975/week11/mysql-laravel-students/resources/views/students/index.blade.php ENDPATH**/ ?>