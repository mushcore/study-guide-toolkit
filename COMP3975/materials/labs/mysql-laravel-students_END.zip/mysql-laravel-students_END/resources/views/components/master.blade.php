<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" >
        <title>{{ config('app.name') }} - {{ $title }}</title>
    </head>
    <body>
        <div class="container">
            <h1>{{ config('app.name') }}</h1>
            <h2>{{ $title }}</h2>
            {{ $content }}
        </div>
    </body>
</html>
