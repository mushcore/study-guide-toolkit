<x-master>
    <x-slot name="content">
        <span style="font-size:xx-large;"><x-slot name="title">Welcome Page</x-slot></span>
        <p>
            <a href="{{ route('students.index') }}">Students</a>
        </p>
    </x-slot>
</x-master>
