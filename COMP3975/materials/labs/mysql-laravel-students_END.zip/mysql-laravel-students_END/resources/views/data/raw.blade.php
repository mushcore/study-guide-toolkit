@extends('layouts.master')

@section('title', 'Raw Query')

@section('content') 

@endsection
