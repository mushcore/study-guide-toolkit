@extends('layouts.master')

@section('title', 'Eloquent ORM')

@section('content') 

@endsection
