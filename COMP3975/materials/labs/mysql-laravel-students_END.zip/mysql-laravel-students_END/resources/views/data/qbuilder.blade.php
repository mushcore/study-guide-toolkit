@extends('layouts.master')

@section('title', 'Query Builder')

@section('content') 

@endsection
