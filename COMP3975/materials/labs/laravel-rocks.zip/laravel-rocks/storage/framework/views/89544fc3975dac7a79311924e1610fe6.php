<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <p class="quote">Beautiful British Columbia</p>
    </div>
</div>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title">Natural beauty</h1>
        <p>The North of British Columbia is a less visited area of Canada, 
        but it offers so much in the way of pure, unadulterated natural beauty.</p>
        <p><a href="#">Read more...</a></p>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title">Vancouver Island & Victoria</h1>
        <p>Vancouver Island offers one of the world’s most divergent ecosystems on the planet.</p>
        <p><a href="#">Read more...</a></p>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-md-12 text-center">
        <h1 class="post-title">Whale and Orca spotting</h1>
        <p>British Columbia is one of only a few destinations where you can experience a three hour whale watching boat trip! </p>
        <p><a href="#">Read more...</a></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/medhatelmasry/_PlayGround/3975/week09/laravel-rocks/resources/views/welcome.blade.php ENDPATH**/ ?>