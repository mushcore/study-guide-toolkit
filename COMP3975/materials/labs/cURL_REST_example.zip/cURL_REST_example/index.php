<?php 
# https://weichie.com/blog/curl-api-calls-with-php/
# https://stackoverflow.com/questions/13420952/php-curl-delete-request
include_once("inc_header.php"); 
?>
 <h3>cURL in PHP</h3>

 <p><a href="get.php">GET EXAMPLE: Get all toon characters</a></p>
 <p><a href="get.php?id=3">GET EXAMPLE: Get toon character with id=3</a></p>
 <p><a href="post.php">POST EXAMPLE: Add John Doe</a></p>
 <p><a href="put.php?id=19">PUT EXAMPLE: Change toon character with id=19 to Jane Doe</a></p>
 <p><a href="delete.php?id=20">DELETE EXAMPLE: Delete toon character with id=20</a></p>
 
 </div>   
 <?php include_once("inc_footer.php"); ?>