<?php
include_once('helper.php');

$id = $_GET["id"];

$data_array =  array(
    "id" => $id,
    "lastName" => "Jane",
    "firstName" => "Doe",
    "occupation" => "Nurse",
    "gender" => "F",
    "pictureUrl" => BASE_URL . "images/flintstone/fred.png",
    "votes" => 0
);

$endpoint = API_URL . "$id";

$make_call  = callAPI('PUT', $endpoint, json_encode($data_array));
$response = json_decode($make_call['body'], false);
$http_code = $make_call['code'];
echo "<hr />";
var_dump($response);
echo "<hr />";
echo "<p>HTTP Code: $http_code</p>";

header("Location: get.php?id=$id");
?>