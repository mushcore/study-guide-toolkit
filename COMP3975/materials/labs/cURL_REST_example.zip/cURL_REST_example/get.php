<?php
include_once('helper.php');

if (isset($_GET["id"])) 
    $endpoint = API_URL . $_GET["id"];
else
    $endpoint = API_URL;

$get_data = callAPI('GET', $endpoint, false);
$response = json_decode($get_data['body'], false);
$http_code = $get_data['code'];

include_once("inc_header.php");
if (is_array($response)) {
    
?>

<h3>Consuming toons API at:</h3>
<h4><?php echo $endpoint?></h4>
<hr />
<table class="table">
    <tbody>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Occupation</th>
            <th>Gender</th>
            <th>Picture</th>
            <th>Votes</th>
        </tr>
        <?php foreach ($response as $item) { ?>
        <tr>
            <td> <?php echo $item->id ?? ''; ?> </td>
            <td> <?php echo ($item->firstName ?? '') . ' ' . ($item->lastName ?? ''); ?> </td>
            <td> <?php echo $item->occupation ?? ''; ?> </td>
            <td> <?php echo $item->gender ?? ''; ?> </td>
            <td> <?php if (!empty($item->pictureUrl)): ?><img style="width:30px" src="<?php echo $item->pictureUrl; ?>" alt="" /><?php endif; ?> </td>
            <td> <?php echo $item->votes ?? ''; ?> </td>
        </tr>
        <?php } ?>
    </tbody>
</table>
<?php } else { ?>

<p><b>Id: </b><?php echo $response->id ?? ''; ?></p>
<p><b>Name: </b><?php echo ($response->firstName ?? '') . ' ' . ($response->lastName ?? ''); ?></p>
<p><b>Occupation: </b><?php echo $response->occupation ?? ''; ?></p>
<p><b>Gender: </b><?php echo $response->gender ?? ''; ?></p>
<p><b>Picture: </b><br /><?php if (!empty($response->pictureUrl)): ?><img style="width:30px" src="<?php echo $response->pictureUrl; ?>" alt="" /><?php endif; ?></p>
<p><b>Votes: </b><?php echo $response->votes ?? ''; ?></p>
<hr />
<?php }  
// echo "<hr />";
// var_dump($response);
echo "<hr />";
echo "<p>HTTP Code: $http_code</p>";

show_source("get.php");
include_once("inc_footer.php");
?>
