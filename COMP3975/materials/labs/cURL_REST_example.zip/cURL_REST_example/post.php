<?php
include_once("inc_header.php");
include_once('helper.php');

$data_array =  array(
    "lastName" => "John",
    "firstName" => "Doe",
    "occupation" => "Builder",
    "gender" => "M",
    "pictureUrl" => BASE_URL . "images/flintstone/fred.png",
    "votes" => 0
);

echo "<h3>POST to " . API_URL . "</h3>";

$make_call = callAPI('POST', API_URL, json_encode($data_array));
$response = json_decode($make_call['body'], false);
$http_code = $make_call['code'];
echo "<hr />";
var_dump($response);
echo "<hr />";
echo "<p>HTTP Code: $http_code</p>";

show_source("post.php");

include_once("inc_footer.php");
?>