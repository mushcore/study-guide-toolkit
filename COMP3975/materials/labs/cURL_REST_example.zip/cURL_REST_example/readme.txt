; enable one of the following

; extension=curl

; extension=D:\apps\php8\ext\php_curl.dll