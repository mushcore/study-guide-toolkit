<?php
include_once('helper.php');

$id = $_GET["id"];

$endpoint = API_URL . "$id";

var_dump($endpoint);

$make_call  = callAPI('DELETE', $endpoint, false);
$response = json_decode($make_call['body'], false);
$http_code = $make_call['code'];
echo "<hr />";
var_dump($response);
echo "<hr />";
echo "<p>HTTP Code: $http_code</p>";

header("Location: get.php");
?>