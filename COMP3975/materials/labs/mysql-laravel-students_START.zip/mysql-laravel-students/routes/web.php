<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentsController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('students', [StudentsController::class, 'index'])->name('students.index');

Route::get('students/create', [StudentsController::class, 'create'])->name('students.create');
Route::post('students/store', [StudentsController::class, 'store'])->name('students.store');

Route::get('students/show/{id}', [StudentsController::class, 'show'])->name('students.show');
Route::get('students/edit/{id}', [StudentsController::class, 'edit'])->name('students.edit');
Route::put('students/update', [StudentsController::class, 'update'])->name('students.update');
Route::get('students/destroy/{id}', [StudentsController::class, 'destroy'])->name('students.destroy');
