<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Symfony\Component\Console\Output\ConsoleOutput;

class StudentsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Student::latest()->paginate(5);
        // dd($data);
        return view("students.index", ['students' => $data])->with(request()->input('page'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
       return view('students.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // validate the input
        $request->validate([
            'FirstName' => 'required',
            'LastName' => 'required',
            'School' => 'required',
        ]);

        // create a new student
        Student::create($request->all());

        // redirect the user to the students list page and send a friendly message
        return redirect()->route('students.index')
                        ->with('success','Student created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        return view('students.show', [
            'student' => Student::findOrFail($id)
        ]);    
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('students.edit', [
            'student' => Student::findOrFail($id)
        ]);    
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Student $student)
    {
        //
        // Validation for required fields (and using some regex to validate our numeric value)
        $request->validate([
            'id' => 'required',
            'FirstName' => 'required',
            'LastName' => 'required',
            'School' => 'required',
        ]); 
        $student = Student::find($request->get('id'));

        // this can be used for debugging
        // it displays in the console
        $output = new ConsoleOutput();
        $output->writeln("STUDENT OBJECT: " . $student);

        // Getting values from the blade template form
        $student->FirstName =  $request->get('FirstName');
        $student->LastName = $request->get('LastName');
        $student->School = $request->get('School');
        $student->save();

        return redirect()->route('students.index')
                        ->with('success','Student updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        // find the student
        $student = Student::find($id);
        // delete the student
        $student->delete();
        // redirect to students list page
        return redirect()->route('students.index')
                        ->with('success','Student deleted successfully');
    }
}
