@extends('layouts.master')

@section('content')
<span style="font-size:xx-large;">Laravel with MySQL</span>
<p>
    <a href="{{ route('students.index') }}">Students</a>
</p>

@endsection
