<?php $__env->startSection('content'); ?>
<span style="font-size:xx-large;">Laravel with MySQL</span>
<p>
    <a href="<?php echo e(route('students.index')); ?>">Students</a>
</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/medhatelmasry/_PlayGround/3975/mysql-laravel-students/resources/views/welcome.blade.php ENDPATH**/ ?>